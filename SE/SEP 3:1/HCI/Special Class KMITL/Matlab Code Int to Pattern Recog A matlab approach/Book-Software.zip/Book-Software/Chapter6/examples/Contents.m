% "Introduction to Pattern Recognition: A MATLAB Approach"
% S. Theodoridis, A. Pikrakis, K. Koutroumbas, D. Cavouras
%
% CHAPTER 6: book examples
%
%   example631 - Example 6.3.1
%   example632 - Example 6.3.2
%   example633 - Example 6.3.3
%   example634 - Example 6.3.4
%   example635 - Example 6.3.5
%   example636 - Example 6.3.6
