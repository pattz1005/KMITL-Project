package midterm;

public interface Command {
    
    public void execute(Inventory inventory);
    
}
