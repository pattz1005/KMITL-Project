package midterm;

public interface Observer {
    public void update();
}
