package Iterator_;
import java.util.Iterator;

public interface Menu {
	public Iterator createIterator();
}
